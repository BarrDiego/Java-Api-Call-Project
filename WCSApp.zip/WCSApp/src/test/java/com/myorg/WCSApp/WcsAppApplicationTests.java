package com.myorg.WCSApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WcsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
